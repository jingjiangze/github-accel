// discover.mjs —— 候选发现：官方来源为主，第三方列表只当 hint
//   node discover.mjs [--force] [-v]
// 产物 candidates.json：{ at, sources:{...}, domains:{ <域>: [ {ip, src, fam} ] } }
//
// 为什么要分来源：本机实测 api.github.com 直连 200 而经代理 403（CF 出口被 GitHub 拉黑），
// 所以每个源都带自己的 via（direct/proxy），不能一刀切。
import fs from 'node:fs'
import path from 'node:path'
import { execFile } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { fam, isV4, isV6, num4, str4 } from './ip.mjs'

const HERE = path.dirname(fileURLToPath(import.meta.url))
const CFG = JSON.parse(fs.readFileSync(path.join(HERE, 'config.json'), 'utf8'))
const OUT = path.join(HERE, 'candidates.json')
const META_CACHE = path.join(HERE, 'meta-cache.json')
const META_CACHE_MAX_H = 168
const ARGV = process.argv.slice(2)
const FORCE = ARGV.includes('--force')
const VERBOSE = ARGV.includes('-v')
const D = CFG.discovery || {}

function log() { console.log(Array.from(arguments).join(' ')) }
function run(exe, args, timeoutMs) {
  return new Promise(function (resolve) {
    // maxBuffer 1MB（2026-10-13 收紧）：源响应体最大几百 KB（hosts 列表 / JSON 段列表），
    // 收紧是为防失控（Node 不预分配，实测对峰值影响可忽略）
    execFile(exe, args, { maxBuffer: 1024 * 1024, windowsHide: true, timeout: timeoutMs, encoding: 'utf8' },
      function (err, out) { resolve({ code: err ? 1 : 0, stdout: out || '' }) })
  })
}
// ---------- 纯函数（可离线自测）；IP 形式校验统一在 ip.mjs（net.isIP 严格） ----------
function rnd() { return Math.random() }

// 每个 /24 抽 per24 个，而不是把整个网段扫完（CloudflareSpeedTest 就是这么控成本的）
function sampleCidr4(cidr, per24, rand) {
  const parts = String(cidr).trim().split('/')
  if (!isV4(parts[0])) return []
  const bits = parts[1] === undefined ? 32 : Number(parts[1])
  const n = num4(parts[0])
  const out = []
  if (bits >= 24) {
    const size = Math.pow(2, 32 - bits)
    out.push(str4(n))
    const step = Math.max(1, Math.floor(size / ((per24 || 1) + 1)))
    for (let i = 1; i <= (per24 || 1) && i * step < size; i++) out.push(str4((n + i * step) >>> 0))
    return out
  }
  const blocks = Math.pow(2, 24 - bits)
  for (let b = 0; b < blocks; b++) {
    const start = (n + b * 256) >>> 0
    for (let i = 0; i < (per24 || 1); i++) out.push(str4((start + 1 + Math.floor(rand() * 254)) >>> 0))
  }
  return out
}
// v6 网段太大，只按 /64 取网络地址（够用来当候选探针，不做全扫）
// 2026-10-13 修：旧版对带 :: 的地址做 split(':').slice(0,4).join(':')，空组原样参与拼接，
// 产出 "2606:50c0:8000:::1"（三冒号）这类非法地址——GitHub /meta 的 pages 恰恰全是
// "2606:50c0:8000::153/128" 单地址，整批被拼坏，objects 因此一直没有可用 v6 候选。
function sampleCidr6(cidr, per64) {
  const parts = String(cidr).trim().split('/')
  if (!isV6(parts[0])) return []
  const bits = parts[1] === undefined ? 128 : Number(parts[1])
  // /128 就是一个地址：原样返回
  if (bits >= 128) return [parts[0].toLowerCase()]
  // 先把 :: 展开收成合法 4 组前缀再拼，避免拼出 "::::1"
  const head = parts[0].toLowerCase().split(':').filter(function (x) { return x !== '' }).slice(0, 4)
  while (head.length < 4) head.push('0')
  const prefix = head.join(':')
  const out = []
  const groups = Math.max(1, Math.min(4, Math.pow(2, Math.max(0, 64 - bits))))
  for (let g = 0; g < groups; g++) {
    out.push(prefix + '::' + (g + 1).toString(16))
  }
  return out.slice(0, per64 || 1)
}
function parseCidrList(text) {
  return String(text).split(/\s+/).map(function (s) { return s.trim() }).filter(function (s) { return s && s.indexOf('/') > 0 })
}
// GitHub /meta：按服务名分组 CIDR（hooks 之类给的是单 IP、domains 给的是域名，都不是 CIDR，丢掉）
function parseMeta(obj) {
  const out = {}
  for (const k of Object.keys(obj || {})) {
    const v = obj[k]
    if (Array.isArray(v) && v.length && typeof v[0] === 'string' && v[0].indexOf('/') > 0) out[k] = v
  }
  return out
}
function parseDoh(json) {
  const ips = []
  try {
    const o = JSON.parse(json)
    for (const a of (o.Answer || [])) if (a && (isV4(a.data) || isV6(a.data))) ips.push(String(a.data).trim())
  } catch (e) {}
  return ips
}
function parseThirdParty(text) {
  const map = {}
  for (const line of String(text).split(/\r?\n/)) {
    const m = line.match(/^(\d{1,3}(?:\.\d{1,3}){3}|[0-9a-fA-F:]+)\s+([a-z0-9._-]+)\s*$/i)
    if (!m) continue
    const ip = m[1], dom = m[2].toLowerCase()
    if (!isV4(ip) && !isV6(ip)) continue
    if (!map[dom]) map[dom] = []
    if (map[dom].indexOf(ip) < 0) map[dom].push(ip)
  }
  return map
}
function readMetaCache() {
  try { return JSON.parse(fs.readFileSync(META_CACHE, 'utf8')) } catch (e) { return null }
}
function dedupe(list) {
  const seen = new Set(), out = []
  for (const x of list) if (x && !seen.has(x)) { seen.add(x); out.push(x) }
  return out
}

// ---------- 取数 ----------
function curlArgs(src) {
  const a = ['-sS', '-g', '--ssl-no-revoke', '--connect-timeout', '6', '--max-time', '25']
  if (src.via === 'proxy' && D.proxy) a.push('-x', D.proxy)
  else a.push('--noproxy', '*')
  if (src.header) a.push('-H', src.header)
  return a
}
async function fetchSrc(src, ms) {
  const r = await run('curl.exe', curlArgs(src).concat([src.url]), ms || 30000)
  return r.stdout.length > 2 ? r.stdout : ''
}

async function main() {
  if (D.enabled === false) { log('discovery.enabled=false，跳过'); return }
  const prev = (function () { try { return JSON.parse(fs.readFileSync(OUT, 'utf8')) } catch (e) { return null } })()
  const freshH = D.refresh_h || 6
  if (!FORCE && prev && Date.now() - prev.at < freshH * 3600e3) {
    log('候选还在有效期内（' + freshH + 'h），用 --force 强制刷新'); return
  }
  const per24 = D.sample_per_24 || 1
  const cap = D.max_per_domain || 64
  const domains = {}
  const sources = {}
  const add = function (dom, ip, src) {
    if (!domains[dom]) domains[dom] = []
    if (!fam(ip)) return
    if (domains[dom].some(function (x) { return x.ip === ip })) return
    if (domains[dom].length >= cap) return
    domains[dom].push({ ip: ip, src: src, fam: fam(ip) })
  }

  // 0) 内置静态表（config.static_ips / static_ips6）——**排在最前**
  //    2026-10-14 修：本仓 hosts 块注释一直写着候选来源含"内置"，但 discover 实际**从未**消费 static_ips。
  //    实测后果：github.com 的 64 个候选全是 /meta 抽样出的老段（192.30.25x，早已退网）与页面段（185.199.x），
  //    能钉的 20.27.177.113（与稳定的 api/codeload 同段）根本不在候选里。
  //    排最前的另一个原因：池子每域每轮只留 ~1 个 explore 名额，且**按候选列表顺序取**——
  //    排在后面就永远被 /meta 垃圾候选挡住，等于没加。
  const totBefore = Object.keys(domains).reduce(function (s, d) { return s + domains[d].length }, 0)
  for (const dom of Object.keys(CFG.domains || {})) {
    for (const ip of ((CFG.static_ips || {})[dom] || [])) add(dom, ip, 'builtin')
    for (const ip of ((CFG.static_ips6 || {})[dom] || [])) add(dom, ip, 'builtin6')
  }
  sources.builtin = Object.keys(domains).reduce(function (s, d) { return s + domains[d].length }, 0) - totBefore

  // 1) 多 DoH 合并（不信单一 DNS 视角）。它是"当前真实答案"，但注意它通常与系统 DNS 基线同值
  //    （基线每轮都会探），所以 explore 优先级让给 builtin 无损失。
  for (const dom of Object.keys(CFG.domains || {})) {
    for (const src of (D.doh || [])) {
      for (const type of ['A', 'AAAA']) {
        const u = { url: String(src.url).replace('DOMAIN', dom).replace('TYPE', type), via: src.via, header: src.header }
        const text = await fetchSrc(u, 15000)
        for (const ip of parseDoh(text)) add(dom, ip, 'doh:' + new URL(src.url).hostname)
      }
    }
  }
  sources.doh_domains = Object.keys(CFG.domains || {}).length

  // 2) GitHub /meta（按服务映射到本项目的域）
  //    2026-10-13 补：/meta 走未认证 API，会被 60 次/时/IP 的限流打掉（403 的错误 JSON 解析出来是
  //    空对象，旧代码把这种当"已解析 0 个服务"直接空手而归）——而 pages 段的 v6 单地址
  //    （2606:50c0:8000::153/128）是 objects/raw/avatars/githubassets 唯一的 v6 来源，
  //    掉一次 objects 整族就没有 v6 候选。兜底：成功时落 meta-cache.json，失败用上次成功结果（TTL 7 天）。
  if (D.github_meta && D.github_meta.url) {
    const text = await fetchSrc(D.github_meta, 30000)
    let meta = null
    try { meta = text ? parseMeta(JSON.parse(text)) : null } catch (e) { meta = null }
    if (meta && !Object.keys(meta).length) meta = null
    let fromCacheH = -1
    if (meta) {
      try { fs.writeFileSync(META_CACHE, JSON.stringify({ at: Date.now(), services: meta }, null, 1)) } catch (e) {}
    } else {
      const c = readMetaCache()
      if (c && c.services && Object.keys(c.services).length) {
        const ageH = (Date.now() - (c.at || 0)) / 3600e3
        if (ageH <= META_CACHE_MAX_H) { meta = c.services; fromCacheH = Math.round(ageH) }
        else log('GitHub /meta 缓存已过 ' + Math.round(ageH) + 'h（上限 ' + META_CACHE_MAX_H + 'h），弃用')
      }
    }
    if (meta) {
      sources.github_meta = Object.keys(meta)
      if (fromCacheH >= 0) sources.github_meta_cached_h = fromCacheH
      for (const dom of Object.keys(D.gh_domains || {})) {
        for (const svc of D.gh_domains[dom]) {
          for (const cidr of (meta[svc] || [])) {
            for (const ip of (fam(cidr.split('/')[0]) === 6 ? sampleCidr6(cidr, 1) : sampleCidr4(cidr, per24, rnd))) add(dom, ip, 'gh-meta:' + svc)
          }
        }
      }
      log('GitHub /meta ' + (fromCacheH >= 0 ? '取不到，用上次缓存（' + fromCacheH + 'h 前）：' : '已解析：') + Object.keys(meta).length + ' 个服务')
    } else log('GitHub /meta 取不到，跳过（不影响其它来源）')
  }

  // 3) Cloudflare 官方网段（给 CF 前置的域）
  for (const [key, v6] of [['cf_ips4', false], ['cf_ips6', true]]) {
    const src = D[key]
    if (!src || !src.url) continue
    const text = await fetchSrc(src, 30000)
    const cidrs = parseCidrList(text)
    if (!cidrs.length) { log(key + ' 取不到，跳过'); continue }
    sources[key] = cidrs.length
    for (const dom of (D.cf_domains || [])) {
      for (const cidr of cidrs) {
        for (const ip of (v6 ? sampleCidr6(cidr, 1) : sampleCidr4(cidr, per24, rnd))) add(dom, ip, key)
      }
    }
    log(key + '：' + cidrs.length + ' 段 -> ' + (D.cf_domains || []).join('/'))
  }

  // 3b) Fastly 官方网段（JSON；给 Fastly 前置的域）
  //     2026-10-13 多站点扩展：pypi.org / files.pythonhosted.org 走 Fastly，
  //     官方列表 https://api.fastly.com/public-ip-list 形态是 { addresses:[...], ipv6_addresses:[...] }
  if (D.fastly_ip_list && D.fastly_ip_list.url) {
    const text = await fetchSrc(D.fastly_ip_list, 30000)
    let v4 = [], v6 = []
    try { const j = JSON.parse(text); v4 = j.addresses || []; v6 = j.ipv6_addresses || [] } catch (e) {}
    const cidrs4 = v4.filter(function (s) { return String(s).indexOf('/') > 0 })
    const cidrs6 = v6.filter(function (s) { return String(s).indexOf('/') > 0 })
    if (!cidrs4.length) { log('fastly_ip_list 取不到，跳过') }
    else {
      sources.fastly_ip_list = cidrs4.length + cidrs6.length
      for (const dom of (D.fastly_domains || [])) {
        for (const cidr of cidrs4) for (const ip of sampleCidr4(cidr, per24, rnd)) add(dom, ip, 'fastly')
        for (const cidr of cidrs6) for (const ip of sampleCidr6(cidr, 1)) add(dom, ip, 'fastly6')
      }
      log('fastly_ip_list：' + cidrs4.length + ' v4 段 + ' + cidrs6.length + ' v6 段 -> ' + (D.fastly_domains || []).join('/'))
    }
  }

  // 4) 第三方列表：只当 hint，不直接写 hosts；也只留本项目关心的域（列表里几百个域与本工具无关）
  //    源支持 "url 字符串" 或 { url, via } 两种写法
  const wanted = new Set(Object.keys(CFG.domains || {}))
  for (const item of (CFG.sources || [])) {
    const url = typeof item === 'string' ? item : item.url
    const via = typeof item === 'string' ? 'direct' : (item.via || 'direct')
    const text = await fetchSrc({ url: url, via: via }, 20000)
    const map = parseThirdParty(text)
    let n = 0
    for (const dom of Object.keys(map)) {
      if (!wanted.has(dom)) continue
      for (const ip of map[dom]) { add(dom, ip, 'hint:' + new URL(url).hostname); n++ }
    }
    if (n) log('第三方 hint ' + new URL(url).hostname + '：' + n + ' 条')
  }

  // 5) 本机历史（warm pool）：上一份候选里被探过的照样保留，外部列表变了也不丢
  if (prev && prev.domains) {
    for (const dom of Object.keys(prev.domains)) {
      for (const e of prev.domains[dom]) if (e.src && e.src.indexOf('history') === 0) add(dom, e.ip, e.src)
    }
  }

  const out = { at: Date.now(), sources: sources, domains: domains }
  fs.writeFileSync(OUT, JSON.stringify(out, null, 1))
  const tot = Object.keys(domains).reduce(function (s, d) { return s + domains[d].length }, 0)
  log('候选已写入 candidates.json：' + Object.keys(domains).length + ' 域 / ' + tot + ' 个候选')
  if (VERBOSE) for (const d of Object.keys(domains)) log('  ', d.padEnd(30), domains[d].length + ' 个', '[' + dedupe(domains[d].map(function (x) { return x.src.split(':')[0] })).join(',') + ']')
}

// 自测仅在本文件是入口时运行（防止劫持导入者的 --selftest）
const isMain = process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url))
if (isMain && ARGV.includes('--selftest')) {
  let bad = 0
  const T = function (name, got, want) {
    const ok = JSON.stringify(got) === JSON.stringify(want)
    if (!ok) bad++
    console.log('  ' + (ok ? 'PASS' : 'FAIL') + '  ' + name + ' = ' + JSON.stringify(got) + (ok ? '' : '，期望 ' + JSON.stringify(want)))
  }
  // 抽样：/24 至少给出网络地址本身，数量受 per24 约束
  const a = sampleCidr4('104.16.0.0/24', 1, function () { return 0.5 })
  T('/24 抽样含网络地址', a[0], '104.16.0.0')
  T('/24 抽样数量', a.length, 2)
  // 大段按 /24 抽：/22 = 4 个 /24，每 /24 一个
  const b = sampleCidr4('104.16.0.0/22', 1, function () { return 0.5 })
  T('/22 每 /24 抽一个', b.length, 4)
  T('/22 落在不同 /24', dedupe(b.map(function (x) { return x.split('.').slice(0, 3).join('.') })).length, 4)
  T('非 v4 段返回空', sampleCidr4('2606:50c0::/32', 1, rnd).length, 0)
  // v6 抽样（2026-10-13 修）：/128 单地址必须原样返回；带 :: 的网段不能再拼出三冒号非法地址
  T('v6 /128 原样返回', sampleCidr6('2606:50c0:8000::153/128', 1), ['2606:50c0:8000::153'])
  T('v6 无前缀按 /128 原样', sampleCidr6('2606:50c0:8000::153', 1), ['2606:50c0:8000::153'])
  const v6s = sampleCidr6('2606:50c0::/32', 4)
  T('v6 /32 抽样数量', v6s.length, 4)
  T('v6 抽样全部合法形式', v6s.every(function (x) { return isV6(x) && fam(x) === 6 }), true)
  T('v6 抽样前缀正确', v6s[0], '2606:50c0:0:0::1')
  T('isV6 拒三冒号等非法形式', [isV6('2606:50c0:8000:::1'), isV6('2606:50c0::::1'), isV6('a::b::c')], [false, false, false])
  // /meta 解析：只收 CIDR 数组（单 IP 与域名列表丢掉）
  T('parseMeta 只收 CIDR 数组', parseMeta({ web: ['140.82.112.0/20'], hooks: ['1.2.3.4'], domains: ['github.com'] }), { web: ['140.82.112.0/20'] })
  // DoH 解析
  T('parseDoh 提取 A/AAAA', parseDoh(JSON.stringify({ Answer: [{ data: '20.205.243.166' }, { data: '2606:50c0::154' }, { data: 'x' }] })), ['20.205.243.166', '2606:50c0::154'])
  T('parseDoh 容错', parseDoh('not json'), [])
  // 第三方列表解析
  const tp = parseThirdParty('# comment\n20.205.243.166 github.com\n2606:50c0::154 raw.githubusercontent.com\nbad line\n')
  T('parseThirdParty 忽略注释与坏行', Object.keys(tp).sort(), ['github.com', 'raw.githubusercontent.com'])
  T('parseThirdParty 计数', tp['github.com'], ['20.205.243.166'])
  // 采样确定性：固定 rnd 时结果可复现
  T('抽样可复现', sampleCidr4('104.16.0.0/22', 2, function () { return 0.5 }), sampleCidr4('104.16.0.0/22', 2, function () { return 0.5 }))
  console.log(bad ? '  自测失败 ' + bad + ' 项' : '  自测全部通过')
  process.exit(bad ? 1 : 0)
}

main().catch(function (e) { console.error('discover 失败：' + ((e && e.stack) || e)); process.exit(1) })
